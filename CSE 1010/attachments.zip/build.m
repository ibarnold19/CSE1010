function collected = build(room, collected)

if room < 0
    
    disp('You need to be inside the maze to build.');
    
elseif collected == 3
    
    disp('Machine built!');
    
    collected = 4;
    
else
    
    disp('You need to collect more parts.');

end