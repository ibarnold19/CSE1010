function collected = collectPart(room, collected, parts)
    
if room < 1
    
    fprintf('\nYou must be inside the maze to collect parts.\n');

elseif parts(room) - 1 ~= collected && parts(room) > 0
    
    fprintf('\nPart %d has not been collected.\n', parts(room) - 1);
    
elseif parts(room) == 0
    
    fprintf('\nRoom does not have a part in it.\n');
    
elseif parts(room) == 1 && parts(room) > 0
    
    fprintf('\nPart %d collected.\n', parts(room));
    
    collected = collected + 1;
    
    parts(room) = 0;
    
else 
    
    fprintf('\nPart %d collected.\n', parts(room));
    
    collected = collected + 1;
    
    parts(room) = 0;
    
end;

end