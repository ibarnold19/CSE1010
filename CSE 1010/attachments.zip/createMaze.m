function maze = createMaze(x)

maze = x;
maze(5,3) = 1;
maze(5,4) = 9;
maze(5,2) = 6;
maze(9,3) = 5;
maze(9,2) = 10;
maze(1,4) = 5;
maze(6,3) = 2;
maze(6,1) = 5;
maze(2,4) = 6;
maze(2,2) = 3;
maze(3,1) = 2;
maze(3,4) = 7;
maze(3,2) = 4;
maze(4,1) = 3;
maze(4,4) = 8;
maze(8,3) = 4;
maze(8,1) = 7;
maze(7,3) = 3;
maze(7,2) = 8;
maze(7,4) = 10;
maze(10,3) = 7;
maze(10,1) = 9;
maze(10, 2) = 11;

end