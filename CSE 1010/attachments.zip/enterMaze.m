function room = enterMaze(room)

if room < 1
    
    fprintf('\nEntering maze.\n');
    fprintf('Entering room 1.\n');
    
    room = 1;
    
else
    
    fprintf('\nYou are already inside the maze.\n');
    
end