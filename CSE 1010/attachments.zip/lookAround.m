function lookAround(maze, room, parts)

if room < 1
    
    fprintf('\nYou are outside the maze.\n');
    
elseif parts(room) > 0
    
    fprintf('\nPart %d is in the room.', parts(room));
    
    fprintf('\nThere are %d door(s) in the room.\n', sum(maze(room,:) > 0));
    
else
    
    fprintf('\nThere are no parts in the room.');
    fprintf('\nThere are %d doors in the room.\n', sum(maze(room,:) > 0));

end