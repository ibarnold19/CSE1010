clear 
clc

win = 0;

x = zeros(10, 4);
maze = createMaze(x);
parts = [0 3 1 0 0 0 0 2 0 0];
collected = 0;
room = 0;
tElapsed = 0;

disp(maze);

fprintf('Welcome to the Maze Adventure game!\nYour objective is to collect the three parts hidden the the maze, in order, build the machine, then escape.\nYou have five minutes to escape.\n\n\n');
fprintf('Available actions once in game:\n');
fprintf('Move (direction): you can move a certain direction to another room. Can move north, east, south, or west of location.\n');
fprintf('Enter maze: enters the maze.\n');
fprintf('Collect part: collects the part in the current room you are in.\n');
fprintf('Look: look around the current room you are in.\n');
fprintf('Status: displays which room you are in, the parts you have collected, if the machine is built, and the time remaining.\n');
fprintf('Build: builds the machine when all parts are collected.\n\n\n');
start = input('Press 1 to begin: ');
fprintf('\n');

while start ~= 1
    
    start = input('Press 1 to begin: \n');
    
end;

tStart = tic;

while win == 0
    
    fprintf('\nCommands:\nmove (direction)\nenter maze\ncollect part\nlook\nstatus\nbuild\n\n');
    
    command = input('Enter a command: ', 's');
        
    if strcmpi(command, 'enter maze') == 1
        
        room = enterMaze(room);
       
    elseif strcmpi(command, 'look') == 1
        
        lookAround(maze, room, parts);
        
    elseif strcmpi(command, 'status') == 1
        
        statusPlayer(room, collected, tElapsed);
        
    elseif strcmpi(command, 'collect part') == 1
        
        collected = collectPart(room, collected, parts);
        
    elseif strmpi(command, 'build') == 1
        
        collectec = build(room, collected);
        
    elseif strcmpi(command, 'move south') == 1 || strcmpi(command, 'move north') == 1 || strcmpi(command, 'move west') == 1 || strcmpi(command, 'move east') == 1
        
        room = moveDirection(command, maze, room, collected);
        
    else
        
        fprintf('\nInvalid command.\n');
        
    end;
        
    tElapsed = toc(tStart);
end;