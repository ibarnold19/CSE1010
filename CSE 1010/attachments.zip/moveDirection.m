function room = moveDirection(str, maze, room, collected)

if room < 1
    
    fprintf('You are outside the maze. You have to enter the maze.');

elseif strfind(str, 'west') > 0 && maze(room, 1) > 0
    
    fprintf('\nEntering room %d.\n', maze(room,1));

    room = maze(room,1);
    
elseif strfind(str, 'east') > 0 && maze(room,2) > 0
    
    fprintf('\nEntering room %d.\n', maze(room, 2));
    
    room = maze(room,1);
    
elseif

end;