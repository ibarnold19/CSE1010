function statusPlayer(room, collected, tElapsed)

if room < 1
    
    fprintf('\nYou are outside the maze.\n');
    
else
    
    fprintf('\nYou are in room %d.\n', room);
    
end;

if collected == 4
    
    fprintf('\nYou have built the machine.\n');
    
elseif collected == 3
    
    fprintf('\nYou have collected parts 1 through 3.\n');
    
elseif collected == 2
    
    fprintf('\nYou have collected parts 1 and 2.\n');
    
elseif collected == 1
    
    fprintf('\nYou have collected part 1.\n');
    
elseif collected == 0
    
    fprintf('\nYou have collected no parts.\n');
    
end;

fprintf('\nTime left: %6.2f seconds.\n', 300 - tElapsed);

end